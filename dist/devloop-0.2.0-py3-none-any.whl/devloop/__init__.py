"""DevLoop - Background agents for development workflow automation."""

__version__ = "0.2.0"
